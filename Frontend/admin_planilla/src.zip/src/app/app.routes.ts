import { Routes } from '@angular/router';
import { Register } from './register/register';
import { AboutComponent } from './about/about';
import { Contact } from './contact/contact';

export const routes: Routes = [
  { path: '', redirectTo: 'register', pathMatch: 'full' },
  { path: 'register', component: Register },
  { path: 'about', component: AboutComponent },
  { path: 'contact', component: Contact }
];
